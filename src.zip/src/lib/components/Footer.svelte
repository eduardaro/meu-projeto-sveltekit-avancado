<footer class="d-flex justify-content-between align-items-center py-1 mt-auto border-top">
  <p class="mb-0 text-body-secondary">&copy; 2024 Company, Inc</p>

    <i class="bi bi-moon-stars"></i>

  <ul class="nav">
    <li class="nav-item">
      <a href="https://www.facebook.com/tl.ifms" target="_blank" class="nav-link px-2 text-body-secondary" aria-label="facebook"
        ><i class="bi bi-facebook"></i></a
      >
    </li>
    <li class="nav-item">
      <a
        href="https://api.whatsapp.com/send?phone=556720200300"
        target="_blank"
        class="nav-link px-2 text-body-secondary"
        aria-label="whatsapp"><i class="bi bi-whatsapp"></i></a
      >
    </li>
    <li class="nav-item">
      <a href="https://twitter.com" target="_blank" class="nav-link px-2 text-body-secondary" aria-label="twitter"
        ><i class="bi bi-twitter"></i></a
      >
    </li>
  </ul>
</footer>
