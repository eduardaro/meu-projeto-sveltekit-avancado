<script>
    export let data;
</script>

<header>
    <h1>Capítulo 03</h1>
    <nav>
        <a href="/03">Início</a>
        <a href="/03/external/posts">Posts</a>
    </nav>
</header>

<main>
    <slot />
</main>

<footer>
    <p>© 2025 Meu Projeto</p>
</footer>
