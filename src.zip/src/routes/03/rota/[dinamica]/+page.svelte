<script>
    let { data } = $props();
  </script>
  
  <p>O primeiro parâmetro da rota é {data.parametro1}.</p>
  <p>O segundo parâmetro da rota é {data.parametro2}.</p>