<script>
	// Nenhum script necessário
</script>

<style>
	@import url('https://fonts.googleapis.com/css2?family=Dancing+Script&family=Quicksand:wght@400;600&display=swap');


	.container {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		min-height: 100vh;
		background: linear-gradient(145deg, #e9d8fd, #fbe4ff);
		padding: 2rem;
		text-align: center;
		color: #5e3c6d;
	}

	h1 {
		font-family: 'Dancing Script', cursive;
		font-size: 4rem;
		color: #a64ac9;
		margin-bottom: 1rem;
	}

	p {
		font-size: 1.3rem;
		max-width: 500px;
	}
</style>

<div class="container">
	<h1>Bem-vindo (a) 💜</h1>
	<p>Este é um espaço feito com carinho, delicadeza e muita luz para você. Sinta-se abraçado (a) e aproveite cada momento por aqui!</p>
</div>
